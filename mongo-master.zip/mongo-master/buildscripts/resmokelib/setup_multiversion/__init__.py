"""Setup multiversion mongodb module."""

from buildscripts.resmokelib.setup_multiversion.setup_multiversion import SetupMultiversionPlugin
